package com.poal.popular.movies.viewmodels

import androidx.lifecycle.MutableLiveData
import com.poal.popular.movies.base.BaseViewModel
import com.poal.popular.movies.models.Movie

class MovieViewModel:BaseViewModel() {

    private val movieTitle = MutableLiveData<String>()
    private val posterUrl = MutableLiveData<String>()
    private val backUrl = MutableLiveData<String>()

    fun bind(movie: Movie) {
        movieTitle.value = movie.title
        posterUrl.value = movie.posterUrl
        backUrl.value = movie.backUrl
    }

    fun getMovieTitle():MutableLiveData<String> {
        return movieTitle
    }

    fun getPosterUrl():MutableLiveData<String> {
        return posterUrl
    }
}

