package com.poal.popular.movies.utils

const val BASE_URL: String = "https://api.themoviedb.org/3/movie/popular?language=en-US&page=1"