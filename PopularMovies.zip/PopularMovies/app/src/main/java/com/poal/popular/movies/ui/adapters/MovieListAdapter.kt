package com.poal.popular.movies.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.poal.popular.movies.R
import com.poal.popular.movies.databinding.ItemMovieBinding
import com.poal.popular.movies.models.Movie
import com.poal.popular.movies.viewmodels.MovieViewModel

class MovieListAdapter: RecyclerView.Adapter<MovieListAdapter.ViewHolder>() {

    private lateinit var  moviesList:List<Movie>

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieListAdapter.ViewHolder {
        val binding: ItemMovieBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.context), R.layout.item_movie, parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MovieListAdapter.ViewHolder, position: Int) {
        holder.bind(moviesList[position])
    }

    override fun getItemCount(): Int {
        return if(::moviesList.isInitialized) moviesList.size else 0
    }

    fun updateMovieList(moviesList:List<Movie>){
        this.moviesList = moviesList
        notifyDataSetChanged()
    }

    class ViewHolder(private val binding: ItemMovieBinding):RecyclerView.ViewHolder(binding.root) {
        private val viewModel = MovieViewModel()

        fun bind(movie:Movie) {
            viewModel.bind(movie)
            binding.viewModel = viewModel
        }
    }
}