package com.poal.popular.movies.network

import com.poal.popular.movies.models.Movie
import io.reactivex.Observable
import retrofit2.http.GET

interface MoviesApi {

    @GET("/movies")
    fun getMovies(): Observable<List<Movie>>

}