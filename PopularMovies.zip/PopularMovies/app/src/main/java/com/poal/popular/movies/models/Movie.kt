package com.poal.popular.movies.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Movie(
    val movieId: Int,
    @field: PrimaryKey
    val title: String,
    val posterUrl: String,
    val backUrl: String)