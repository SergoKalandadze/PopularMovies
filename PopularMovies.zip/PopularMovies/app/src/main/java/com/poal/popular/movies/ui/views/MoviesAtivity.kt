package com.poal.popular.movies.ui.views

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.poal.popular.movies.R

class MoviesAtivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.movies_activity)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                    .replace(R.id.container, MovieListFragment.newInstance())
                    .commitNow()
        }
    }

}
